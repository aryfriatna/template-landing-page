// Component loader function
function loadComponent(elementId, componentPath) {
  fetch(componentPath)
    .then((response) => response.text())
    .then((data) => {
      document.getElementById(elementId).innerHTML = data

      // Initialize component-specific functionality
      if (componentPath.includes("header")) {
        initializeHeader()
      }
    })
    .catch((error) => {
      console.error("Error loading component:", error)
    })
}

// Header initialization
function initializeHeader() {
  // Mobile menu toggle
  const mobileMenuBtn = document.getElementById("mobile-menu-btn")
  const mobileMenu = document.getElementById("mobile-menu")

  if (mobileMenuBtn && mobileMenu) {
    mobileMenuBtn.addEventListener("click", () => {
      mobileMenu.classList.toggle("hidden")
    })
  }

  // Active navigation highlighting
  setActiveNavigation()
}

// Set active navigation based on current page
function setActiveNavigation() {
  const currentPage = window.location.pathname.split("/").pop().replace(".html", "") || "index"
  const navLinks = document.querySelectorAll(".nav-link")

  navLinks.forEach((link) => {
    const linkPage = link.getAttribute("data-page")
    if ((currentPage === "index" && linkPage === "home") || currentPage === linkPage) {
      link.classList.remove("text-gray-600")
      link.classList.add("text-primary", "font-medium", "border-b-2", "border-primary", "pb-1")
    }
  })
}

// Utility functions
const BanMasterUtils = {
  // Smooth scroll to element
  scrollTo: (elementId) => {
    const element = document.getElementById(elementId)
    if (element) {
      element.scrollIntoView({
        behavior: "smooth",
        block: "start",
      })
    }
  },

  // Form validation
  validateForm: (formId) => {
    const form = document.getElementById(formId)
    if (!form) return false

    const requiredFields = form.querySelectorAll("[required]")
    let isValid = true

    requiredFields.forEach((field) => {
      if (!field.value.trim()) {
        field.classList.add("border-red-500")
        isValid = false
      } else {
        field.classList.remove("border-red-500")
      }
    })

    return isValid
  },

  // Show notification
  showNotification: (message, type = "success") => {
    const notification = document.createElement("div")
    notification.className = `fixed top-4 right-4 z-50 p-4 rounded-lg shadow-lg transition-all duration-300 ${
      type === "success" ? "bg-primary text-white" : "bg-red-500 text-white"
    }`
    notification.textContent = message

    document.body.appendChild(notification)

    setTimeout(() => {
      notification.remove()
    }, 3000)
  },
}
